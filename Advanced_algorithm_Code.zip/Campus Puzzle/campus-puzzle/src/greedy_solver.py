from src.models import ClassInfo, Room, ScheduleEntry
from src.utils import TIME_SLOTS


def build_group_lookup(student_groups):
    """
    Creates a lookup showing which student groups attend each class.

    Example:
        CS101 -> {"G1", "G2"}
        MATH101 -> {"G1", "G3"}
    """

    class_groups = {}

    for group_id, class_ids in student_groups.items():
        for class_id in class_ids:
            if class_id not in class_groups:
                class_groups[class_id] = set()

            class_groups[class_id].add(group_id)

    return class_groups


def share_student_group(class_id_1, class_id_2, class_groups):
    """
    Returns True if two classes share at least one student group.
    """

    groups_1 = class_groups.get(class_id_1, set())
    groups_2 = class_groups.get(class_id_2, set())

    return bool(groups_1.intersection(groups_2))


def has_student_group_conflict(
    course,
    time_slot,
    schedule,
    class_groups
):
    """
    Checks whether a course would conflict with an already
    scheduled class because of shared student groups.
    """

    for entry in schedule:
        if entry.time_slot != time_slot:
            continue

        if share_student_group(
            course.class_id,
            entry.class_id,
            class_groups
        ):
            return True

    return False


def has_professor_conflict(
    course,
    time_slot,
    schedule,
    classes_by_id
):
    """
    Checks whether the professor is already teaching
    another class at the proposed time.
    """

    for entry in schedule:
        if entry.time_slot != time_slot:
            continue

        scheduled_course = classes_by_id[entry.class_id]

        if scheduled_course.professor == course.professor:
            return True

    return False


def is_room_available(room_id, time_slot, schedule):
    """
    Checks whether the room is already occupied at the
    proposed time slot.
    """

    for entry in schedule:
        if (
            entry.room_id == room_id
            and entry.time_slot == time_slot
        ):
            return False

    return True


def find_feasible_room(course, time_slot, rooms, schedule):
    """
    Finds the first room that can accommodate the class
    and is available at the given time.
    """

    for room in rooms:

        if room.capacity < course.students:
            continue

        if not is_room_available(
            room.room_id,
            time_slot,
            schedule
        ):
            continue

        return room

    return None


def greedy_schedule(classes, rooms, student_groups):
    """
    Creates a baseline schedule using a greedy strategy.

    Classes are sorted by descending student enrolment.
    Each class is assigned to the first feasible
    time-slot and room combination.
    """

    sorted_classes = sorted(
        classes,
        key=lambda course: course.students,
        reverse=True
    )

    classes_by_id = {
        course.class_id: course
        for course in classes
    }

    class_groups = build_group_lookup(student_groups)

    schedule = []
    unscheduled = []

    for course in sorted_classes:

        assigned = False

        for time_slot in TIME_SLOTS:

            if has_professor_conflict(
                course,
                time_slot,
                schedule,
                classes_by_id
            ):
                continue

            if has_student_group_conflict(
                course,
                time_slot,
                schedule,
                class_groups
            ):
                continue

            room = find_feasible_room(
                course,
                time_slot,
                rooms,
                schedule
            )

            if room is None:
                continue

            waste = room.capacity - course.students

            schedule.append(
                ScheduleEntry(
                    class_id=course.class_id,
                    time_slot=time_slot,
                    room_id=room.room_id,
                    waste=waste
                )
            )

            assigned = True
            break

        if not assigned:
            unscheduled.append(course)

    return schedule, unscheduled