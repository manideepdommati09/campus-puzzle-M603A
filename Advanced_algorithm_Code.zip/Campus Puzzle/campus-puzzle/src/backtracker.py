from src.models import ScheduleEntry
from src.utils import TIME_SLOTS


class BacktrackingSolver:

    def __init__(
        self,
        classes,
        rooms,
        student_groups
    ):
        self.classes = classes
        self.rooms = rooms
        self.student_groups = student_groups

        self.class_by_id = {
            course.class_id: course
            for course in classes
        }

        self.class_groups = (
            self.build_group_lookup(
                student_groups
            )
        )

        self.conflict_graph = (
            self.build_conflict_graph()
        )

        self.best_schedule = []
        self.best_waste = float("inf")

        self.current_schedule = []

    def build_group_lookup(
        self,
        student_groups
    ):
        class_groups = {}

        for group_id, class_ids in student_groups.items():

            for class_id in class_ids:

                if class_id not in class_groups:
                    class_groups[class_id] = set()

                class_groups[class_id].add(
                    group_id
                )

        return class_groups

    def share_student_group(
        self,
        class_id_1,
        class_id_2
    ):
        groups_1 = self.class_groups.get(
            class_id_1,
            set()
        )

        groups_2 = self.class_groups.get(
            class_id_2,
            set()
        )

        return bool(
            groups_1.intersection(groups_2)
        )

    def build_conflict_graph(self):
        graph = {
            course.class_id: set()
            for course in self.classes
        }

        for i in range(len(self.classes)):

            for j in range(i + 1, len(self.classes)):

                class_1 = self.classes[i]
                class_2 = self.classes[j]

                same_professor = (
                    class_1.professor
                    == class_2.professor
                )

                same_group = (
                    self.share_student_group(
                        class_1.class_id,
                        class_2.class_id
                    )
                )

                if same_professor or same_group:

                    graph[class_1.class_id].add(
                        class_2.class_id
                    )

                    graph[class_2.class_id].add(
                        class_1.class_id
                    )

        return graph

    def has_conflict(
        self,
        course,
        time_slot
    ):
        for entry in self.current_schedule:

            if entry.time_slot != time_slot:
                continue

            other = self.class_by_id[
                entry.class_id
            ]

            if other.class_id in self.conflict_graph[
                course.class_id
            ]:
                return True

        return False

    def is_room_available(
        self,
        room,
        time_slot
    ):
        for entry in self.current_schedule:

            if (
                entry.time_slot == time_slot
                and entry.room_id == room.room_id
            ):
                return False

        return True

    def get_feasible_options(
        self,
        course
    ):
        options = []

        for time_slot in TIME_SLOTS:

            if self.has_conflict(
                course,
                time_slot
            ):
                continue

            for room in self.rooms:

                if room.capacity < course.students:
                    continue

                if not self.is_room_available(
                    room,
                    time_slot
                ):
                    continue

                waste = (
                    room.capacity
                    - course.students
                )

                options.append(
                    (
                        time_slot,
                        room,
                        waste
                    )
                )

        return options

    def choose_next_class(
        self,
        remaining_classes
    ):
        best_course = None
        best_options = None

        for course in remaining_classes:

            options = self.get_feasible_options(
                course
            )

            if (
                best_options is None
                or len(options)
                < len(best_options)
            ):
                best_course = course
                best_options = options

        return best_course, best_options

    def update_best_solution(self):
        current_count = len(
            self.current_schedule
        )

        best_count = len(
            self.best_schedule
        )

        current_waste = sum(
            entry.waste
            for entry in self.current_schedule
        )

        if current_count > best_count:

            self.best_schedule = list(
                self.current_schedule
            )

            self.best_waste = current_waste

        elif (
            current_count == best_count
            and current_waste < self.best_waste
        ):

            self.best_schedule = list(
                self.current_schedule
            )

            self.best_waste = current_waste

    def search(
        self,
        remaining_classes
    ):
        self.update_best_solution()

        if not remaining_classes:
            return True

        course, options = (
            self.choose_next_class(
                remaining_classes
            )
        )

        next_remaining = [
            item
            for item in remaining_classes
            if item.class_id != course.class_id
        ]

        # Best-effort handling:
        # If this class has no feasible option,
        # skip it and continue with the remaining classes.
        if not options:
            self.search(next_remaining)
            return False

        options.sort(
            key=lambda option: option[2]
        )

        for (
            time_slot,
            room,
            waste
        ) in options:

            entry = ScheduleEntry(
                class_id=course.class_id,
                time_slot=time_slot,
                room_id=room.room_id,
                waste=waste
            )

            self.current_schedule.append(
                entry
            )

            solved = self.search(
                next_remaining
            )

            if solved:
                return True

            self.current_schedule.pop()

        # If none of the available assignments
        # produced a complete solution, skip this
        # class and continue searching for the
        # best partial solution.
        self.search(next_remaining)

        return False

    def explain_unscheduled_class(
        self,
        course
    ):
        largest_capacity = max(
            room.capacity
            for room in self.rooms
        )

        if course.students > largest_capacity:
            return (
                "No available room has sufficient capacity. "
                f"Required: {course.students} seats; "
                f"Largest room: {largest_capacity} seats."
            )

        return (
            "No feasible time and room combination remained "
            "under the professor, student-group, and room "
            "occupancy constraints."
        )

    def solve(self):
        ordered_classes = sorted(
            self.classes,
            key=lambda course: course.students,
            reverse=True
        )

        solved = self.search(
            ordered_classes
        )

        scheduled_ids = {
            entry.class_id
            for entry in self.best_schedule
        }

        unscheduled = [
            course
            for course in self.classes
            if course.class_id not in scheduled_ids
        ]

        unscheduled_reasons = {
            course.class_id: self.explain_unscheduled_class(
                course
            )
            for course in unscheduled
        }

        return (
            self.best_schedule,
            unscheduled,
            unscheduled_reasons,
            self.best_waste,
            solved
        )


def backtracking_schedule(
    classes,
    rooms,
    student_groups
):
    solver = BacktrackingSolver(
        classes,
        rooms,
        student_groups
    )

    return solver.solve()