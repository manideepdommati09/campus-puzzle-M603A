from src.utils import TIME_SLOTS


def build_group_lookup(student_groups):
    """
    Creates a mapping from each class to the student groups
    that attend that class.

    Example:
        CS101 -> {"G1", "G2"}
        MATH101 -> {"G1", "G3"}
    """

    class_groups = {}

    for group_id, class_ids in student_groups.items():
        for class_id in class_ids:
            if class_id not in class_groups:
                class_groups[class_id] = set()

            class_groups[class_id].add(group_id)

    return class_groups


def share_student_group(class_id_1, class_id_2, class_groups):
    """
    Returns True if two classes share at least one student group.
    """

    groups_1 = class_groups.get(class_id_1, set())
    groups_2 = class_groups.get(class_id_2, set())

    return bool(groups_1.intersection(groups_2))


def have_conflict(
    class_1,
    class_2,
    class_groups
):
    """
    Returns True if two classes cannot occur
    at the same time.

    A conflict exists when:
    1. They have the same professor, or
    2. They share a student group.
    """

    same_professor = (
        class_1.professor == class_2.professor
    )

    same_student_group = share_student_group(
        class_1.class_id,
        class_2.class_id,
        class_groups
    )

    return same_professor or same_student_group


def build_conflict_graph(classes, student_groups):
    """
    Builds an undirected conflict graph.

    Each class is a node.

    If two classes conflict, an edge is added
    in both directions.
    """

    class_groups = build_group_lookup(student_groups)

    graph = {
        course.class_id: set()
        for course in classes
    }

    for i in range(len(classes)):
        for j in range(i + 1, len(classes)):

            class_1 = classes[i]
            class_2 = classes[j]

            if have_conflict(
                class_1,
                class_2,
                class_groups
            ):
                graph[class_1.class_id].add(
                    class_2.class_id
                )

                graph[class_2.class_id].add(
                    class_1.class_id
                )

    return graph


def welsh_powell(graph):
    """
    Applies the Welsh-Powell graph colouring algorithm.

    Nodes are processed in descending order of degree.

    Each node receives the smallest colour that is not
    already used by any neighbouring node.
    """

    degrees = {
        class_id: len(neighbours)
        for class_id, neighbours in graph.items()
    }

    ordered_nodes = sorted(
        graph.keys(),
        key=lambda class_id: (-degrees[class_id], class_id)
    )

    colours = {}

    for class_id in ordered_nodes:

        used_colours = {
            colours[neighbour]
            for neighbour in graph[class_id]
            if neighbour in colours
        }

        colour = 0

        while colour in used_colours:
            colour += 1

        colours[class_id] = colour

    return colours


def convert_colours_to_time_slots(colours):
    """
    Converts graph colours into actual time slots.

    Colour 0 -> first time slot
    Colour 1 -> second time slot
    etc.

    If more colours are required than available time slots,
    the extra classes are marked as unscheduled.
    """

    time_assignment = {}
    unscheduled = []

    for class_id, colour in colours.items():

        if colour < len(TIME_SLOTS):
            time_assignment[class_id] = TIME_SLOTS[colour]
        else:
            unscheduled.append(class_id)

    return time_assignment, unscheduled


def graph_colour_schedule(classes, student_groups):
    """
    Complete Stage 2 process:

    1. Build conflict graph.
    2. Apply Welsh-Powell colouring.
    3. Convert colours to time slots.
    """

    graph = build_conflict_graph(
        classes,
        student_groups
    )

    colours = welsh_powell(graph)

    time_assignment, unscheduled = (
        convert_colours_to_time_slots(colours)
    )

    return graph, colours, time_assignment, unscheduled