from src.models import ScheduleEntry


def optimise_rooms_for_slot(
    slot_classes,
    rooms
):
    """
    Uses dynamic programming to find the room assignment
    with minimum total wasted capacity for one time slot.

    Each room can be used at most once in the slot.
    """

    if not slot_classes:
        return [], 0

    # DP state:
    # (class_index, used_room_mask) -> (total_waste, assignments)
    #
    # used_room_mask stores which rooms have already been used.

    dp = {
        (0, 0): (0, [])
    }

    for class_index, course in enumerate(slot_classes):

        next_dp = {}

        for (
            current_index,
            used_room_mask
        ), (
            current_waste,
            current_assignments
        ) in dp.items():

            for room_index, room in enumerate(rooms):

                # Check whether this room is already used.
                if used_room_mask & (1 << room_index):
                    continue

                # Room must be large enough.
                if room.capacity < course.students:
                    continue

                waste = room.capacity - course.students

                new_mask = (
                    used_room_mask
                    | (1 << room_index)
                )

                new_waste = current_waste + waste

                key = (
                    class_index + 1,
                    new_mask
                )

                new_assignments = (
                    current_assignments
                    + [(course, room)]
                )

                if key not in next_dp:
                    next_dp[key] = (
                        new_waste,
                        new_assignments
                    )
                else:
                    old_waste, _ = next_dp[key]

                    if new_waste < old_waste:
                        next_dp[key] = (
                            new_waste,
                            new_assignments
                        )

        dp = next_dp

        # If no valid assignment exists, stop.
        if not dp:
            return None, None

    # Find the solution with the lowest total waste.
    best_waste = None
    best_assignments = None

    for total_waste, assignments in dp.values():

        if (
            best_waste is None
            or total_waste < best_waste
        ):
            best_waste = total_waste
            best_assignments = assignments

    return best_assignments, best_waste


def optimise_all_rooms(
    time_assignment,
    classes,
    rooms
):
    """
    Optimises room allocation separately for every time slot.

    Returns:
        schedule
        unscheduled
        total_waste
    """

    classes_by_id = {
        course.class_id: course
        for course in classes
    }

    schedule = []
    unscheduled = []
    total_waste = 0

    # Process every time slot.
    for time_slot in sorted(
        set(time_assignment.values())
    ):

        slot_classes = []

        for class_id, assigned_slot in time_assignment.items():

            if assigned_slot == time_slot:
                slot_classes.append(
                    classes_by_id[class_id]
                )

        # Larger classes first makes the DP input easier to inspect.
        slot_classes.sort(
            key=lambda course: course.students,
            reverse=True
        )

        assignments, slot_waste = (
            optimise_rooms_for_slot(
                slot_classes,
                rooms
            )
        )

        if assignments is None:

            # No complete room assignment exists
            # for this time slot.
            for course in slot_classes:
                unscheduled.append(course)

            continue

        for course, room in assignments:

            waste = (
                room.capacity
                - course.students
            )

            schedule.append(
                ScheduleEntry(
                    class_id=course.class_id,
                    time_slot=time_slot,
                    room_id=room.room_id,
                    waste=waste
                )
            )

        total_waste += slot_waste

    return schedule, unscheduled, total_waste