import json
from pathlib import Path

from src.models import ClassInfo, Room


TIME_SLOTS = [
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "14:00",
    "15:00",
    "16:00"
]


def load_constraints(file_path: str):
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(
            f"Constraints file not found: {file_path}"
        )

    with path.open("r", encoding="utf-8") as file:
        data = json.load(file)

    return data


def load_classes(data):
    classes = []

    for item in data["classes"]:
        classes.append(
            ClassInfo(
                class_id=item["id"],
                students=item["students"],
                professor=item["professor"]
            )
        )

    return classes


def load_rooms(data):
    rooms = []

    for item in data["rooms"]:
        rooms.append(
            Room(
                room_id=item["id"],
                capacity=item["capacity"]
            )
        )

    return rooms