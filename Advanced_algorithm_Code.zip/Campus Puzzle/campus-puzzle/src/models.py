from dataclasses import dataclass


@dataclass
class ClassInfo:
    class_id: str
    students: int
    professor: str


@dataclass
class Room:
    room_id: str
    capacity: int


@dataclass
class ScheduleEntry:
    class_id: str
    time_slot: str
    room_id: str
    waste: int