# The Campus Puzzle - University Scheduling Optimisation

## 1. Project Overview

The Campus Puzzle is a university timetable scheduling and optimisation system developed to assign classes to available time slots and lecture rooms while satisfying hard scheduling constraints.

The system is designed around four algorithmic stages:

1. Greedy scheduling
2. Conflict graph construction and Welsh-Powell graph colouring
3. Dynamic programming for room optimisation
4. Backtracking with best-effort scheduling

The system aims to:

* Prevent professor timetable conflicts.
* Prevent student-group timetable conflicts.
* Prevent room double-booking.
* Ensure that every class is assigned only to a room with sufficient capacity.
* Reduce unused room capacity.
* Identify classes that cannot be scheduled.
* Provide a useful partial timetable when a complete timetable is impossible.
* Leave a small number of difficult cases for informed human intervention.

The project uses a small test dataset during development and is designed around the wider university scheduling problem of approximately 5,000 students, 300 professors and 50 lecture halls.

## 2. Problem Definition

University timetable scheduling is a constraint-based optimisation problem.

Each class must receive:

```text
Class -> Time Slot -> Room
```

The assignment must satisfy several hard constraints.

### Professor Constraint

A professor cannot teach two classes during the same time slot.

### Student-Group Constraint

Two classes attended by the same student group cannot occur at the same time.

This constraint is important because two classes may have different professors but still create a timetable conflict if students are expected to attend both.

### Room Constraint

A room cannot be assigned to more than one class during the same time slot.

### Room Capacity Constraint

The number of students enrolled in a class cannot exceed the capacity of the assigned room.

### Resource Utilisation

The system attempts to minimise unused room capacity.

For every scheduled class:

```text
Room Waste = Room Capacity - Number of Students
```

A class assigned to a room with exactly the required capacity has:

```text
Room Waste = 0
```

and is therefore a perfect fit.

## 3. Dataset

The main dataset is:

```text
data/constraints.json
```

The dataset contains:

* Class IDs
* Number of enrolled students
* Professor IDs
* Room IDs
* Room capacities
* Student-group mappings

Example class:

```json
{
    "id": "CS101",
    "students": 120,
    "professor": "P01"
}
```

Example room:

```json
{
    "id": "R101",
    "capacity": 150
}
```

Example student-group mapping:

```json
"G1": [
    "CS101",
    "MATH101",
    "PHY101"
]
```

This means CS101, MATH101 and PHY101 cannot occur at the same time because students in group G1 attend all three classes.

A separate testing dataset is provided:

```text
data/test_constraints.json
```

This dataset contains an intentionally impossible class to test the best-effort functionality.

## 4. Project Structure

```text
campus-puzzle/
│
├── data/
│   ├── constraints.json
│   └── test_constraints.json
│
├── src/
│   ├── __init__.py
│   ├── models.py
│   ├── greedy_solver.py
│   ├── engine.py
│   ├── optimizer.py
│   ├── backtracker.py
│   └── utils.py
│
├── main.py
├── README.md
├── requirements.txt
├── .gitignore
└── venv/
```

# 5. Architect's Defense

The project deliberately uses different algorithms for different parts of the scheduling problem.

The algorithms are not expected to perform the same task. Each stage reduces a particular part of the problem before the next stage is applied.

The wider problem contains approximately 5,000 students, 300 professors and 50 rooms. The current demonstration dataset is smaller, but the algorithm choices are designed around the structure of the larger problem.

## Stage 1 - Greedy Baseline

### Algorithm

Greedy scheduling with descending student-count ordering.

### Why we used it

We used the greedy algorithm because it provides a fast initial solution without exploring every possible timetable.

Classes are sorted by number of students in descending order. Larger classes are considered first because they have fewer feasible rooms.

For each class, the algorithm searches through the available time slots and rooms until it finds the first feasible combination.

### Complexity

Let:

* `n` = number of classes
* `t` = number of time slots
* `r` = number of rooms

Sorting the classes requires:

```text
O(n log n)
```

The placement process may inspect time slots, rooms and existing assignments. With the current implementation, the practical cost is approximately:

```text
O(n² × t × r)
```

because conflict and occupancy checks may scan existing scheduled classes.

Space usage is approximately:

```text
O(n)
```

for the schedule and supporting lookup structures, excluding the input data.

### Scalability

The greedy stage is the fastest scheduling stage and is suitable for producing an initial timetable for a large class set.

For the wider 5,000-student university problem, the number of classes rather than the number of students is the primary factor affecting this algorithm's runtime.

The purpose of this stage is not to guarantee an optimal timetable. It provides a quick baseline against which later optimisation stages can be compared.

## Stage 2 - Conflict Graph + Welsh-Powell

### Algorithm

Conflict graph construction followed by Welsh-Powell graph colouring.

### Why we used it

We used graph colouring because timetable conflicts can naturally be represented as graph edges.

Each class becomes a vertex.

An edge is created when:

* Two classes have the same professor, or
* Two classes share a student group.

Two connected classes cannot receive the same colour.

Each colour represents a time slot.

This approach directly converts the hard time-conflict problem into a graph-colouring problem. Welsh-Powell orders vertices by decreasing degree before assigning colours, which is particularly appropriate for timetable-style conflicts. The original Welsh-Powell paper explicitly connects graph colouring with timetabling problems.

### Complexity

For `n` classes, the conflict graph is constructed by checking class pairs:

```text
O(n²)
```

In the worst case, the graph can contain:

```text
O(n²)
```

edges.

Sorting vertices by degree requires:

```text
O(n log n)
```

The colouring phase depends on the graph representation and number of conflict edges. With an adjacency-list implementation, the practical cost is related to the number of vertices and edges.

### Scalability

The graph approach is useful for a large university because the conflict structure can be constructed independently of room allocation.

For the wider problem, the graph can contain many conflicts, but the method avoids searching through complete room/time combinations at this stage.

The result is a conflict-free time-slot assignment that can be passed to the room optimisation stage.

## Stage 3 - Dynamic Programming Room Optimisation

### Algorithm

Dynamic programming with a room-usage bitmask.

### Why we used it

After Stage 2 assigns time slots, the remaining problem is to select rooms efficiently.

We used dynamic programming because the room allocation problem contains repeated subproblems.

For each time slot, the algorithm considers:

```text
Class index
Used room mask
```

The room mask records which rooms have already been assigned.

The objective is to minimise:

```text
Total Room Waste
```

where:

```text
Room Waste = Room Capacity - Students
```

The algorithm keeps the best assignment for each DP state rather than repeatedly calculating the same partial allocation.

### Complexity

Let:

* `k` = number of classes in one time slot
* `r` = number of rooms

The number of possible room masks is:

```text
2^r
```

For each state, feasible rooms are considered.

A practical upper-bound description for a slot is approximately:

```text
O(k × r × 2^r)
```

with memory approximately:

```text
O(k × 2^r)
```

depending on how assignment paths are stored.

### Scalability

The number of rooms is only 50 in the wider problem, but the DP state space grows exponentially with the number of rooms if all 50 rooms are represented in a single unrestricted bitmask.

For this reason, the DP stage is best understood as a focused room-allocation optimisation stage rather than the complete solution to the 5,000-student scheduling problem.

The implementation is particularly suitable when each time slot has a manageable number of active room choices.

This decomposition keeps the room optimisation separate from the much larger conflict problem.

## Stage 4 - Backtracking + Best Effort

### Algorithm

Recursive backtracking with Minimum Remaining Values and best-solution tracking.

### Why we used it

We used backtracking because some scheduling decisions may need to be reconsidered.

A greedy decision can look valid initially but prevent another class from being scheduled later.

The backtracking algorithm can therefore:

1. Select a class.
2. Generate feasible time/room choices.
3. Try an assignment.
4. Continue recursively.
5. Backtrack when the choice prevents further progress.
6. Keep the best valid schedule found.

The solver uses the Minimum Remaining Values principle by selecting the class with the fewest currently feasible options.

This places the most constrained class first and can reduce unnecessary search.

### Best-Effort Behaviour

A complete timetable is not always possible.

When a class has no feasible assignment, the algorithm skips that class and continues searching for the remaining classes.

The solver retains the best solution according to:

1. Maximum number of scheduled classes.
2. Minimum total room waste when the number of scheduled classes is equal.

This prevents one impossible class from causing the entire timetable to fail.

### Complexity

Backtracking has exponential worst-case behaviour.

If a class can have approximately `t × r` possible time/room combinations, the unrestricted search space can grow approximately as:

```text
O((t × r)^n)
```

where `n` is the number of classes being searched.

Space complexity is approximately:

```text
O(n)
```

for recursion and the current assignment, excluding the conflict graph and stored best solution.

### Scalability

Backtracking is not intended to independently solve all classes in the 5,000-student university scenario.

Its purpose in this architecture is to act as a recovery and best-effort stage after faster methods have already reduced the problem.

The Minimum Remaining Values heuristic, conflict checks and capacity filtering reduce the practical search space.

This combination reflects a common approach to university timetabling: heuristic algorithms perform most of the work while search and human intervention can be used for difficult residual cases.

# 6. Algorithm Comparison

The four stages have different responsibilities.

| Stage | Algorithm           | Main Purpose             | Main Strength            | Main Limitation                   |
| ----- | ------------------- | ------------------------ | ------------------------ | --------------------------------- |
| 1     | Greedy              | Initial timetable        | Fast                     | Local decisions                   |
| 2     | Welsh-Powell        | Conflict-free time slots | Handles graph conflicts  | Does not allocate rooms           |
| 3     | Dynamic Programming | Room allocation          | Reduces room waste       | Room-state space grows with rooms |
| 4     | Backtracking        | Recovery and best effort | Can reconsider decisions | Exponential worst case            |

The stages therefore complement each other rather than competing to perform exactly the same task.

# 7. Results on Original Dataset

The original dataset contains:

```text
Classes: 10
Rooms: 5
Time slots: 7
```

### Stage 1

```text
Scheduled:       10
Unscheduled:      0
Total room waste: 445 seats
```

### Stage 2

```text
Colours required: 3
Scheduled by colouring: 10
Unscheduled: 0
```

Stage 2 does not calculate room waste because its purpose is conflict-free time allocation.

### Stage 3

```text
Scheduled:       10
Unscheduled:      0
Total room waste: 185 seats
```

Compared with Stage 1:

```text
445 - 185 = 260 seats
```

The room waste is reduced by approximately:

```text
58.4%
```

### Stage 4

```text
Scheduled:       10
Unscheduled:      0
Total room waste: 85 seats
Complete solution: Yes
```

Compared with Stage 1:

```text
445 - 85 = 360 seats
```

The room waste is reduced by approximately:

```text
80.9%
```

The Stage 4 result for the original dataset is:

```text
CS101     09:00     R101      Wasted 30 seats
DB101     09:00     R103      Wasted 10 seats
NET101    09:00     R104      Wasted 5 seats
MATH101   10:00     R102      Perfect Fit
WEB101    10:00     R105      Wasted 5 seats
AI101     11:00     R104      Perfect Fit
CS102     11:00     R102      Wasted 10 seats
PHY101    11:00     R103      Perfect Fit
ENG101    12:00     R105      Wasted 10 seats
HIST101   14:00     R105      Wasted 15 seats
```

Total room waste:

```text
85 seats
```

# 8. Conflict Report

A separate test dataset is used to demonstrate how the system behaves when the complete timetable is impossible.

The test dataset contains 11 classes instead of 10.

One additional class is:

```text
Class: MEGA101
Students: 200
Professor: P10
```

The available rooms are:

```text
R101 -> 150 seats
R102 -> 100 seats
R103 -> 80 seats
R104 -> 60 seats
R105 -> 50 seats
```

Therefore:

```text
Required capacity: 200
Largest available room: 150
Capacity shortage: 50 seats
```

### Minimum Conflict List

```text
MEGA101
```

Reason:

```text
No available room has sufficient capacity.

Required: 200 seats
Largest room: 150 seats
```

This is a capacity conflict rather than a professor or student-group conflict.

The Welsh-Powell stage can still assign MEGA101 a time-slot colour because it has no graph conflict with another class. This does not mean that MEGA101 can physically be scheduled.

When room capacity is considered, MEGA101 becomes infeasible.

The best-effort Stage 4 solver therefore schedules the remaining 10 classes and reports:

```text
Scheduled: 10
Unscheduled: 1
Complete solution: No
```

This demonstrates why time-slot feasibility and room feasibility must be considered separately.

# 9. Manual Fix Log

The automated system is designed to leave a small number of difficult cases for a university timetable manager rather than forcing an invalid assignment.

The human manager can use the software output as follows.

### Step 1 - Review Unscheduled Classes

The manager first checks the:

```text
UNSCHEDULED CLASSES
```

section.

Each unresolved class is displayed with its student count, professor and reason.

### Step 2 - Identify the Cause

The manager determines whether the problem is caused by:

* Room capacity
* Room availability
* Professor conflicts
* Student-group conflicts
* Insufficient time slots
* A combination of constraints

### Step 3 - Consider Institutional Options

For a capacity problem such as MEGA101, the manager could investigate:

* A larger lecture hall
* An additional teaching location
* An additional time slot
* Splitting the class into multiple sessions
* Changing the class delivery arrangement

The software does not automatically make these decisions because they depend on university policies, teaching requirements and physical resources.

### Step 4 - Check the Manual Change

Before accepting a manual change, the manager should verify that it does not create:

* A professor conflict
* A student-group conflict
* A room conflict
* A room-capacity violation

### Step 5 - Record the Manual Intervention

The manager should record:

```text
Class:
Original status:
Reason:
Manual action:
New time:
New room:
Person approving change:
Date:
```

### Example Manual Fix Log

```text
Class: MEGA101

Original status:
Unscheduled

Reason:
Required 200 seats but the largest available room has 150 seats.

Possible manual action:
Check whether a larger lecture hall is available or whether
the class can be divided into additional sessions.

Final action:
To be completed by university timetable manager.

Validation:
New room/time assignment must be checked against all
professor, student-group and room constraints.
```

The manual stage is intended for the small residual percentage of difficult cases that require information or decisions outside the automated model.

# 10. Best-Effort Test

The file:

```text
data/test_constraints.json
```

contains the intentionally impossible `MEGA101` class.

When this dataset is used, the expected Stage 4 result is:

```text
Scheduled:   10
Unscheduled: 1
Complete solution: No
Total room waste: 85 seats
```

The unscheduled output is:

```text
MEGA101   Students: 200   Professor: P10

Reason:
No available room has sufficient capacity.
Required: 200 seats.
Largest room: 150 seats.
```

This test demonstrates that the solver does not discard the other valid classes simply because one class is impossible.

# 11. Validation of Hard Constraints

The final schedule is expected to satisfy the following conditions:

### No professor double-booking

A professor must not appear in two classes at the same time.

### No student-group conflict

Classes belonging to the same student group must have different time slots.

### No room double-booking

A room must not appear in two assignments at the same time.

### Room capacity

For every assignment:

```text
Students <= Room Capacity
```

### Best-effort requirement

If every class cannot be scheduled, the system must:

* Retain the largest feasible schedule.
* Identify unscheduled classes.
* Provide a reason.
* Allow a human manager to resolve the remaining cases.

# 12. Complexity Summary

Let:

```text
n = number of classes
t = number of time slots
r = number of rooms
E = number of conflict edges
```

| Stage                | Time Complexity                                              | Space Complexity         |
| -------------------- | ------------------------------------------------------------ | ------------------------ |
| Greedy               | Approximately O(n² × t × r)                                  | O(n)                     |
| Conflict Graph       | O(n²)                                                        | O(n + E)                 |
| Welsh-Powell         | Depends on graph representation; sorting includes O(n log n) | O(n + E)                 |
| DP Room Optimisation | Approximately O(k × r × 2^r) per slot                        | Approximately O(k × 2^r) |
| Backtracking         | Exponential worst case, approximately O((t × r)^n)           | O(n + E)                 |

The complexity figures describe the implemented approach and its worst-case or practical bounds rather than claiming that all stages scale equally well.

The architecture therefore uses:

```text
Fast heuristic
      ↓
Conflict reduction
      ↓
Room optimisation
      ↓
Targeted backtracking
      ↓
Human intervention if necessary
```

This staged approach is more appropriate than applying unrestricted backtracking to the entire university scheduling problem.

# 13. Running the Project

Open Command Prompt in the project directory.

Activate the virtual environment:

```text
venv\Scripts\activate
```

Run the application:

```text
python main.py
```

The program executes all four stages and displays:

* Greedy schedule
* Conflict graph
* Welsh-Powell colouring
* Dynamic programming room assignment
* Backtracking schedule
* Unscheduled classes
* Unscheduled reasons
* Total room waste

# 14. Switching Between Datasets

The normal application should use:

```python
data = load_constraints(
    "data/constraints.json"
)
```

The best-effort test can be run by temporarily changing it to:

```python
data = load_constraints(
    "data/test_constraints.json"
)
```

After testing, restore:

```python
data = load_constraints(
    "data/constraints.json"
)
```

# 15. Requirements

The project currently uses only Python standard-library modules.

`requirements.txt` contains:

```text
# No external dependencies required.
# The project uses Python standard library modules.
```

No third-party package installation is required.

# 16. GitHub Deliverables

The repository contains the required project components:

```text
/data
    constraints.json
    test_constraints.json

/src
    models.py
    greedy_solver.py
    engine.py
    optimizer.py
    backtracker.py
    utils.py

main.py
README.md
requirements.txt
.gitignore
```

The README documents:

* Algorithm justification
* Complexity
* Scalability considerations
* Conflict handling
* Best-effort behaviour
* Conflict report
* Manual intervention process
* Testing dataset
* Final results

# 17. Conclusion

The Campus Puzzle demonstrates a staged approach to university timetable optimisation.

The greedy algorithm provides a fast baseline. Conflict graph construction and Welsh-Powell colouring address professor and student-group conflicts at the time-slot level. Dynamic programming then improves room utilisation. Finally, backtracking provides a recovery mechanism for difficult cases and preserves the best feasible timetable when a complete solution cannot be found.

On the original demonstration dataset, the system schedules all 10 classes with 85 seats of total room waste.

The best-effort test demonstrates that when an impossible class requires more capacity than any available room, the system does not discard the remaining timetable. Instead, it reports the unresolved class and provides a reason that a university timetable manager can use for manual intervention.

The resulting architecture combines algorithmic scheduling, optimisation and human decision-making rather than relying on a single algorithm for every part of the problem.
