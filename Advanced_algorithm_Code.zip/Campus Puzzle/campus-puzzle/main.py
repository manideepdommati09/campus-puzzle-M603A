from src.utils import load_constraints, load_classes, load_rooms
from src.greedy_solver import greedy_schedule
from src.engine import graph_colour_schedule
from src.optimizer import optimise_all_rooms
from src.backtracker import backtracking_schedule


def print_greedy_results(schedule, unscheduled):
    print()
    print("=" * 70)
    print("STAGE 1 - GREEDY BASELINE")
    print("=" * 70)

    print()
    print("SCHEDULED CLASSES")
    print("-" * 70)

    if schedule:
        for entry in schedule:

            if entry.waste == 0:
                details = "Perfect Fit"
            else:
                details = f"Wasted {entry.waste} seats"

            print(
                f"{entry.class_id:<10}"
                f"{entry.time_slot:<10}"
                f"{entry.room_id:<10}"
                f"{details}"
            )
    else:
        print("No classes were scheduled.")

    print()
    print("UNSCHEDULED CLASSES")
    print("-" * 70)

    if unscheduled:
        for course in unscheduled:
            print(
                f"{course.class_id:<10}"
                f"Students: {course.students:<5}"
                f"Professor: {course.professor}"
            )
    else:
        print("None")

    print()
    print("-" * 70)
    print(f"Scheduled:   {len(schedule)}")
    print(f"Unscheduled: {len(unscheduled)}")

    total_waste = sum(
        entry.waste
        for entry in schedule
    )

    print(f"Total room waste: {total_waste} seats")
    print("-" * 70)


def print_graph_results(
    graph,
    colours,
    time_assignment,
    unscheduled
):
    print()
    print("=" * 70)
    print("STAGE 2 - CONFLICT GRAPH + WELSH-POWELL")
    print("=" * 70)

    print()
    print("CONFLICT GRAPH")
    print("-" * 70)

    for class_id in sorted(graph):

        neighbours = sorted(
            graph[class_id]
        )

        if neighbours:
            print(
                f"{class_id:<10} -> "
                f"{', '.join(neighbours)}"
            )
        else:
            print(
                f"{class_id:<10} -> No conflicts"
            )

    print()
    print("WELSH-POWELL COLOURING")
    print("-" * 70)

    ordered_classes = sorted(
        colours,
        key=lambda class_id: (
            colours[class_id],
            class_id
        )
    )

    for class_id in ordered_classes:

        colour = colours[class_id]

        if class_id in time_assignment:
            time_slot = time_assignment[class_id]
        else:
            time_slot = "UNSCHEDULED"

        print(
            f"{class_id:<10}"
            f"Colour: {colour:<5}"
            f"Time: {time_slot}"
        )

    print()
    print("STAGE 2 SUMMARY")
    print("-" * 70)

    print(
        f"Colours required: "
        f"{max(colours.values()) + 1 if colours else 0}"
    )

    print(
        f"Scheduled by colouring: "
        f"{len(time_assignment)}"
    )

    print(
        f"Unscheduled: "
        f"{len(unscheduled)}"
    )

    if unscheduled:

        print()
        print("UNSCHEDULED CLASSES")
        print("-" * 70)

        for class_id in unscheduled:
            print(class_id)

    print("-" * 70)


def print_dp_results(
    schedule,
    unscheduled,
    total_waste
):
    print()
    print("=" * 70)
    print("STAGE 3 - DYNAMIC PROGRAMMING ROOM OPTIMISATION")
    print("=" * 70)

    print()
    print("OPTIMISED ROOM ASSIGNMENT")
    print("-" * 70)

    if schedule:

        sorted_schedule = sorted(
            schedule,
            key=lambda entry: (
                entry.time_slot,
                entry.class_id
            )
        )

        for entry in sorted_schedule:

            if entry.waste == 0:
                details = "Perfect Fit"
            else:
                details = f"Wasted {entry.waste} seats"

            print(
                f"{entry.class_id:<10}"
                f"{entry.time_slot:<10}"
                f"{entry.room_id:<10}"
                f"{details}"
            )

    else:
        print(
            "No classes received a room assignment."
        )

    print()
    print("UNSCHEDULED CLASSES")
    print("-" * 70)

    if unscheduled:

        for course in unscheduled:
            print(
                f"{course.class_id:<10}"
                f"Students: {course.students:<5}"
                f"Professor: {course.professor}"
            )

    else:
        print("None")

    print()
    print("-" * 70)
    print(f"Scheduled:   {len(schedule)}")
    print(f"Unscheduled: {len(unscheduled)}")
    print(f"Total room waste: {total_waste} seats")
    print("-" * 70)


def print_backtracking_results(
    schedule,
    unscheduled,
    unscheduled_reasons,
    total_waste,
    solved
):
    print()
    print("=" * 70)
    print("STAGE 4 - BACKTRACKING + BEST EFFORT")
    print("=" * 70)

    print()
    print("BACKTRACKING SCHEDULE")
    print("-" * 70)

    if schedule:

        sorted_schedule = sorted(
            schedule,
            key=lambda entry: (
                entry.time_slot,
                entry.class_id
            )
        )

        for entry in sorted_schedule:

            if entry.waste == 0:
                details = "Perfect Fit"
            else:
                details = f"Wasted {entry.waste} seats"

            print(
                f"{entry.class_id:<10}"
                f"{entry.time_slot:<10}"
                f"{entry.room_id:<10}"
                f"{details}"
            )

    else:
        print("No classes were scheduled.")

    print()
    print("UNSCHEDULED CLASSES")
    print("-" * 70)

    if unscheduled:

        for course in unscheduled:

            print(
                f"{course.class_id:<10}"
                f"Students: {course.students:<5}"
                f"Professor: {course.professor}"
            )

            print(
                f"Reason: "
                f"{unscheduled_reasons[course.class_id]}"
            )

    else:
        print("None")

    print()
    print("-" * 70)

    print(
        f"Complete solution: "
        f"{'Yes' if solved else 'No'}"
    )

    print(f"Scheduled:   {len(schedule)}")
    print(f"Unscheduled: {len(unscheduled)}")
    print(f"Total room waste: {total_waste} seats")

    print("-" * 70)


def main():

    data = load_constraints(
        "data/constraints.json"
    )

    classes = load_classes(data)
    rooms = load_rooms(data)

    print("=" * 70)
    print("CAMPUS PUZZLE SCHEDULING SYSTEM")
    print("=" * 70)

    print(f"Total classes: {len(classes)}")
    print(f"Total rooms: {len(rooms)}")

    # STAGE 1
    schedule, unscheduled = greedy_schedule(
        classes,
        rooms,
        data["student_groups"]
    )

    print_greedy_results(
        schedule,
        unscheduled
    )

    # STAGE 2
    (
        graph,
        colours,
        time_assignment,
        graph_unscheduled
    ) = graph_colour_schedule(
        classes,
        data["student_groups"]
    )

    print_graph_results(
        graph,
        colours,
        time_assignment,
        graph_unscheduled
    )

    # STAGE 3
    (
        dp_schedule,
        dp_unscheduled,
        dp_waste
    ) = optimise_all_rooms(
        time_assignment,
        classes,
        rooms
    )

    print_dp_results(
        dp_schedule,
        dp_unscheduled,
        dp_waste
    )

    # STAGE 4
    (
        backtrack_schedule,
        backtrack_unscheduled,
        backtrack_reasons,
        backtrack_waste,
        backtrack_solved
    ) = backtracking_schedule(
        classes,
        rooms,
        data["student_groups"]
    )

    print_backtracking_results(
        backtrack_schedule,
        backtrack_unscheduled,
        backtrack_reasons,
        backtrack_waste,
        backtrack_solved
    )


if __name__ == "__main__":
    main()